from warnings import warn

warn("IPython.utils.jsonutil has moved to jupyter_client.jsonutil", stacklevel=2)

from jupyter_client.jsonutil import *
